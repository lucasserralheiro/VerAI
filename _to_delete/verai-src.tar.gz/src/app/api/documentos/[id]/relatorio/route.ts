import { NextRequest, NextResponse } from 'next/server'
import type { Analise, Documento } from '@prisma/client'
import { prisma } from '@/lib/prisma'
import { getAuthUser } from '@/lib/auth'
import { podeVerDocumento } from '@/lib/visibilidade'
import { buildRelatorioPath, getUpload, putUpload } from '@/lib/storage'
import { gerarRelatorioPdf } from '@/lib/pdf/gerarRelatorio'

async function obterBufferRelatorio(
  documento: Documento & { uploadedBy: { nome: string } },
  analise: Analise
): Promise<Buffer> {
  if (analise.caminhoRelatorioPdf) {
    try {
      return await getUpload(analise.caminhoRelatorioPdf)
    } catch {
      // cache inválido (arquivo não existe mais) — regenera abaixo
    }
  }

  const buffer = await gerarRelatorioPdf(documento, analise)
  const caminhoRelativo = buildRelatorioPath(documento.id)
  const url = await putUpload(caminhoRelativo, buffer, 'application/pdf')
  await prisma.analise.update({
    where: { id: analise.id },
    data: { caminhoRelatorioPdf: url, relatorioGeradoEm: new Date() },
  })

  return buffer
}

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const usuario = await getAuthUser(request)
  if (!usuario) {
    return NextResponse.json({ error: 'não autenticado' }, { status: 401 })
  }

  const { id } = await params
  const documento = await prisma.documento.findUnique({
    where: { id },
    include: { uploadedBy: { select: { nome: true } }, analise: true },
  })
  if (!documento) {
    return NextResponse.json({ error: 'documento não encontrado' }, { status: 404 })
  }

  const podeVer = await podeVerDocumento(usuario, documento)
  if (!podeVer) {
    return NextResponse.json({ error: 'acesso negado' }, { status: 403 })
  }

  if (documento.status !== 'concluido' || !documento.analise) {
    return NextResponse.json(
      { error: 'relatório só está disponível para documentos com análise concluída' },
      { status: 400 }
    )
  }

  const buffer = await obterBufferRelatorio(documento, documento.analise)

  await prisma.acessoDocumento.create({
    data: { documentoId: id, usuarioId: usuario.id, acao: 'baixou_relatorio' },
  })

  return new NextResponse(new Uint8Array(buffer), {
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="relatorio-${documento.nomeArquivo}.pdf"`,
    },
  })
}
