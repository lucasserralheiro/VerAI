import type { Documento, Prisma } from '@prisma/client'
import { prisma } from './prisma'
import type { AuthUser } from './auth'

async function clienteIdsPermitidos(usuario: AuthUser): Promise<string[] | null> {
  // null = sem restrição (admin vê todos os clientes)
  if (usuario.role === 'admin') return null

  const registro = await prisma.usuario.findUnique({
    where: { id: usuario.id },
    select: { clientesPermitidos: { select: { id: true } } },
  })
  return (registro?.clientesPermitidos ?? []).map((c) => c.id)
}

async function regrasQueBatemComUsuario(email: string) {
  const regras = await prisma.regraNotificacao.findMany()
  return regras.filter((regra) => {
    const lista = Array.isArray(regra.destinatarios) ? (regra.destinatarios as unknown[]) : []
    return lista.includes(email)
  })
}

export async function documentosVisiveisWhere(usuario: AuthUser): Promise<Prisma.DocumentoWhereInput> {
  const idsClientes = await clienteIdsPermitidos(usuario)
  const restricaoCliente: Prisma.DocumentoWhereInput =
    idsClientes === null ? {} : { clienteId: { in: idsClientes } }

  if (usuario.role === 'admin') return restricaoCliente
  if (usuario.role === 'uploader') return { AND: [restricaoCliente, { uploadedById: usuario.id }] }

  const regras = await regrasQueBatemComUsuario(usuario.email)
  const tipos = regras.filter((r) => r.criterioTipo === 'tipoDocumento').map((r) => r.criterioValor)
  const palavras = regras.filter((r) => r.criterioTipo === 'palavraChaveNome').map((r) => r.criterioValor)

  const OR: Prisma.DocumentoWhereInput[] = [{ uploadedById: usuario.id }]
  if (tipos.length > 0) OR.push({ tipo: { in: tipos } })
  for (const palavra of palavras) {
    OR.push({ nomeArquivo: { contains: palavra, mode: 'insensitive' } })
  }
  return { AND: [restricaoCliente, { OR }] }
}

export async function podeVerDocumento(usuario: AuthUser, documento: Documento): Promise<boolean> {
  const idsClientes = await clienteIdsPermitidos(usuario)
  if (idsClientes !== null && !idsClientes.includes(documento.clienteId)) return false

  if (usuario.role === 'admin' || documento.uploadedById === usuario.id) return true
  if (usuario.role === 'uploader') return false

  const regras = await regrasQueBatemComUsuario(usuario.email)
  return regras.some((regra) => {
    if (regra.criterioTipo === 'tipoDocumento') return regra.criterioValor === documento.tipo
    if (regra.criterioTipo === 'palavraChaveNome') {
      return documento.nomeArquivo.toLowerCase().includes(regra.criterioValor.toLowerCase())
    }
    return false
  })
}

export async function clientesVisiveisWhere(usuario: AuthUser): Promise<Prisma.ClienteWhereInput> {
  const ids = await clienteIdsPermitidos(usuario)
  return ids === null ? {} : { id: { in: ids } }
}

export async function podeVerCliente(usuario: AuthUser, clienteId: string): Promise<boolean> {
  const ids = await clienteIdsPermitidos(usuario)
  return ids === null || ids.includes(clienteId)
}
